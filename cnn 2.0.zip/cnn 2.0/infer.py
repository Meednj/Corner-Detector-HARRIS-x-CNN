from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image

from corner_detector.model import load_model
from corner_detector.postprocess import find_corners


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run CNN corner detection on an image.")
    parser.add_argument("--checkpoint", default="runs/corner_detector_best.pt")
    parser.add_argument("--image", required=True)
    parser.add_argument("--out", default="prediction.png")
    parser.add_argument(
        "--threshold",
        type=float,
        default=-1.0,
        help="Detection threshold in [0, 1]. Use -1 for automatic CNN thresholding.",
    )
    parser.add_argument("--nms-kernel", type=int, default=21)
    parser.add_argument("--max-corners", type=int, default=28)
    parser.add_argument("--border-margin", type=int, default=10)
    parser.add_argument(
        "--detector",
        choices=("harris", "cnn"),
        default="cnn",
        help="Use cnn for the trained heatmap model, or harris for a classical baseline.",
    )
    parser.add_argument(
        "--preprocess",
        choices=("gray", "canny", "invert", "sobel"),
        default="gray",
        help="Input transform before the CNN. Gray matches the synthetic training input.",
    )
    parser.add_argument("--quality-level", type=float, default=0.04)
    parser.add_argument("--min-distance", type=int, default=16)
    parser.add_argument("--block-size", type=int, default=7)
    parser.add_argument("--harris-k", type=float, default=0.04)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--save-heatmap", action="store_true")
    return parser.parse_args()


def load_grayscale(path: str | Path) -> tuple[np.ndarray, np.ndarray]:
    rgb = np.array(Image.open(path).convert("RGB"))
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
    return rgb, gray


def preprocess_image(gray: np.ndarray, mode: str) -> np.ndarray:
    if mode == "gray":
        result = gray.copy()
    elif mode == "invert":
        result = 1.0 - gray
    elif mode == "canny":
        gray_u8 = (gray * 255).astype(np.uint8)
        result = cv2.Canny(gray_u8, 50, 150).astype(np.float32) / 255.0
    elif mode == "sobel":
        grad_x = cv2.Sobel(gray, cv2.CV_32F, 1, 0)
        grad_y = cv2.Sobel(gray, cv2.CV_32F, 0, 1)
        result = np.clip(cv2.magnitude(grad_x, grad_y) * 4.0, 0.0, 1.0)
    else:
        raise ValueError(f"unknown preprocess mode: {mode}")

    lo = float(result.min())
    hi = float(result.max())
    if hi - lo > 1e-6:
        result = (result - lo) / (hi - lo)
    return result.astype(np.float32)


def auto_threshold(heatmap: np.ndarray) -> float:
    """Choose a conservative per-image threshold from the strongest CNN responses."""
    top = heatmap[heatmap >= np.percentile(heatmap, 99.0)]
    if top.size == 0:
        return 0.5
    return float(np.clip(top.mean() - top.std(), 0.1, 0.95))


@torch.no_grad()
def predict_heatmap(model: torch.nn.Module, gray: np.ndarray, device: torch.device) -> np.ndarray:
    height, width = gray.shape
    model_size = getattr(model, "image_size", 128)
    resized = cv2.resize(gray, (model_size, model_size), interpolation=cv2.INTER_LINEAR)
    tensor = torch.from_numpy(resized[None, None, ...]).float().to(device)
    logits = model(tensor)
    heatmap = torch.sigmoid(logits)[0, 0].cpu().numpy()
    return cv2.resize(heatmap, (width, height), interpolation=cv2.INTER_LINEAR)


def overlay_corners(rgb: np.ndarray, corners: list[tuple[int, int, float]]) -> np.ndarray:
    output = rgb.copy()
    for x, y, score in corners:
        radius = 3 if score < 0.7 else 4
        cv2.circle(output, (x, y), radius, (255, 40, 40), thickness=2)
        cv2.circle(output, (x, y), 1, (255, 255, 255), thickness=-1)
    return output


def detect_harris_corners(
    gray: np.ndarray,
    max_corners: int,
    quality_level: float,
    min_distance: int,
    block_size: int,
    harris_k: float,
    border_margin: int,
) -> list[tuple[int, int, float]]:
    gray_u8 = (gray * 255).astype(np.uint8)
    corners = cv2.goodFeaturesToTrack(
        gray_u8,
        maxCorners=max_corners,
        qualityLevel=quality_level,
        minDistance=min_distance,
        blockSize=block_size,
        useHarrisDetector=True,
        k=harris_k,
    )
    if corners is None:
        return []

    h, w = gray.shape
    detections = []
    for index, [[x, y]] in enumerate(corners):
        x_i = int(round(float(x)))
        y_i = int(round(float(y)))
        if (
            x_i < border_margin
            or y_i < border_margin
            or x_i >= w - border_margin
            or y_i >= h - border_margin
        ):
            continue
        score = 1.0 - index / max(1, len(corners))
        detections.append((x_i, y_i, score))
    return detections


def main() -> None:
    args = parse_args()
    rgb, gray = load_grayscale(args.image)
    if args.detector == "harris":
        corners = detect_harris_corners(
            gray,
            max_corners=args.max_corners,
            quality_level=args.quality_level,
            min_distance=args.min_distance,
            block_size=args.block_size,
            harris_k=args.harris_k,
            border_margin=args.border_margin,
        )
    else:
        if not args.checkpoint:
            raise ValueError("--checkpoint is required when --detector cnn")
        device = torch.device(args.device)
        model = load_model(args.checkpoint, device=device)
        model_input = preprocess_image(gray, args.preprocess)
        heatmap = predict_heatmap(model, model_input, device)
        threshold = auto_threshold(heatmap) if args.threshold < 0 else args.threshold
        print(f"using threshold={threshold:.4f}")

        if args.save_heatmap:
            heatmap_vis = np.clip(heatmap * 255.0, 0, 255).astype(np.uint8)
            heatmap_color = cv2.applyColorMap(heatmap_vis, cv2.COLORMAP_INFERNO)
            heatmap_path = str(Path(args.out).with_name(f"{Path(args.out).stem}_heatmap.png"))
            cv2.imwrite(heatmap_path, heatmap_color)
            print(f"heatmap saved to {heatmap_path}")

        corners = find_corners(
            heatmap,
            threshold=threshold,
            nms_kernel=args.nms_kernel,
            max_corners=args.max_corners,
            border_margin=args.border_margin,
        )
    output = overlay_corners(rgb, corners)
    Image.fromarray(output).save(args.out)
    print(f"detected_corners={len(corners)} saved={args.out}")


if __name__ == "__main__":
    main()
